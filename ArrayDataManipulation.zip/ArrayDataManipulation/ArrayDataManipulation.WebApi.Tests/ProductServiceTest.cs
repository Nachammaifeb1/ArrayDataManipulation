using Array_Data_Manipulation.Controllers;
using NUnit.Framework;
using Product.Services;

namespace ProductServiceTest
{
    public class ProductServiceTest
    {
        private ProductService _productService;
        [SetUp]
        public void Setup()
        {
            _productService = new ProductService();
        }

        [Test]
        public void ReverseTest()
        {
            int[] testData = { 1, 2, 3, 4, 5, 6 };
            int[] outPutData = { 6, 5, 4, 3, 2, 1 };

            var obj = _productService.Reverse(testData);

            Assert.AreEqual(obj, outPutData);
            Assert.Pass();
        }


        [Test]
        public void DeletePartTest()
        {
            int[] testData = { 1, 2, 3, 4, 5, 6 };
            int position = 4;
            int[] outPutData = { 1, 2, 3, 5, 6 };

            var obj = _productService.DeletePart(position,testData);
            Assert.AreEqual(obj, outPutData);
            Assert.Pass();
        }
    }
}