﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Product.Services
{
    public class ProductService : IProductService
    {
        public ProductService()
        {

        }

        public int[] Reverse(int[] productIds)
        {
            try
            {
                int[] ReversedArray = new int[productIds.Length];
                int ReversedArrayIndex = 0;
                for (int i = productIds.Length - 1; i >= 0; i--)
                {

                    ReversedArray[ReversedArrayIndex] = productIds[i];
                    ReversedArrayIndex++;
                }
                return ReversedArray;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int[] DeletePart(int Position, int[] productIds)
        {
            try
            {
                int[] UpdatedArray = new int[productIds.Length - 1];
                int UpdatedArrayIndex = 0;

                for (int i = 0; i < productIds.Length; i++)
                {
                    if (Position != i + 1)
                    {
                        UpdatedArray[UpdatedArrayIndex] = productIds[i];
                        UpdatedArrayIndex++;
                    }

                }
                return UpdatedArray;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
