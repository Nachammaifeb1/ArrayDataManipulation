﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Product.Services
{
    public interface IProductService
    {
        int[] Reverse(int[] productIds);
         int[] DeletePart(int Position, int[] productIds);
    }
}
